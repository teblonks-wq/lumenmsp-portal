import { Router, Request, Response } from 'express';
import { requireAdmin } from '../middleware/auth';
import { websiteStats, visitorList } from '../lib/chat';
import { getGroup, setSetting } from '../lib/settings';
import { bufferConfigured, getChannels, channelFor, createBufferPost } from '../lib/buffer';
import { aiMarketingPost, aiComposeConfigured } from '../lib/ai-compose';
import { publishNewsArticle, websitePublishConfigured, renderArticlePreview } from '../lib/news-publish';
import { searchFreeImages } from '../lib/images';
import {
  audience, audienceCoverage, createCampaign, updateDraft, sendTest, startSending, pauseSending,
  retryFailed, contactForUnsubToken, optOutByToken, campaignSignatureHtml,
} from '../lib/mass-mailer';
import { aiMassMailEmail, aiImproveEmailHtml } from '../lib/ai-compose';
import { pool } from '../db/pool';

const router = Router();

// Marketing landing — reached from the Admin page's Marketing card.
router.get('/marketing', requireAdmin, async (req: Request, res: Response) => {
  res.render('marketing/index', { user: req.session.user! });
});

// Marketing → Chat Bot — enable/disable the website chat + set its hours (default 09:00–17:00 Mon–Fri).
router.get('/marketing/chatbot', requireAdmin, async (req: Request, res: Response) => {
  const g = await getGroup('chatbot').catch(() => ({} as Record<string, string>));
  res.render('marketing/chatbot', { user: req.session.user!, g, notice: req.query.msg || null });
});

router.post('/marketing/chatbot', requireAdmin, async (req: Request, res: Response) => {
  const b = req.body as Record<string, string>;
  await setSetting('chatbot', 'enabled', (b.enabled === 'on' || b.enabled === 'true') ? 'true' : 'false');
  await setSetting('chatbot', 'open_time', b.open_time || '09:00');
  await setSetting('chatbot', 'close_time', b.close_time || '17:00');
  const days = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'].filter((d) => b['day_' + d]);
  await setSetting('chatbot', 'days', days.join(',') || 'mon,tue,wed,thu,fri');
  res.redirect('/marketing/chatbot?msg=' + encodeURIComponent('Chat Bot settings saved'));
});

// Marketing → Website Stats — page views, unique visitors, top pages/referrers, live now.
router.get('/marketing/website-stats', requireAdmin, async (req: Request, res: Response) => {
  const period = ['today', 'week', 'month'].includes(String(req.query.period)) ? String(req.query.period) : 'week';
  let stats: any = null, visitors: any[] = [];
  try { stats = await websiteStats(); } catch (e: any) { stats = { error: e.message }; }
  try { visitors = await visitorList(period); } catch { visitors = []; }
  res.render('marketing/website-stats', { user: req.session.user!, stats, visitors, period });
});

// ── Marketing → Socials studio (2026-07-09 rewrite) ──────────────────────────────
// STATELESS 4-step flow — nothing is stored in the Portal:
//   1. URLs + content notes + Lumen's take
//   2. Generate with Claude (one meaty end-user article + LinkedIn + Facebook copy)
//   3. Push to website (writes a static page into the live site's /news)
//   4. Push to Buffer (now, or pick a date/time)
router.get('/marketing/socials', requireAdmin, async (req: Request, res: Response) => {
  res.render('marketing/socials', {
    user: req.session.user!,
    aiReady: await aiComposeConfigured(),
    bufferReady: await bufferConfigured(),
    websiteReady: websitePublishConfigured(),
  });
});

// Fetch a page and strip it to readable-ish text (capped) for Claude's source material.
async function extractUrl(url: string): Promise<{ url: string; text: string } | null> {
  try {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 10000);
    const res = await fetch(url, { signal: ctl.signal, redirect: 'follow', headers: { 'User-Agent': 'LumenMSP-Portal-Studio/1.0' } });
    clearTimeout(timer);
    if (!res.ok) return null;
    const html = await res.text();
    const text = html
      .replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<nav[\s\S]*?<\/nav>/gi, ' ').replace(/<footer[\s\S]*?<\/footer>/gi, ' ')
      .replace(/<[^>]+>/g, ' ').replace(/&[a-z#0-9]+;/gi, ' ').replace(/\s+/g, ' ').trim();
    return text.length > 100 ? { url, text: text.slice(0, 5000) } : null;
  } catch { return null; }
}

router.post('/marketing/socials/generate', requireAdmin, async (req: Request, res: Response) => {
  try {
    const urls: string[] = String(req.body.urls || '').split(/[\n,]+/).map((u) => u.trim()).filter((u) => /^https?:\/\//i.test(u)).slice(0, 4);
    const content = String(req.body.content || '').trim();
    const take = String(req.body.take || '').trim();
    if (!urls.length && !content) { res.status(400).json({ ok: false, error: 'Give me at least a URL or some content to work from.' }); return; }
    const sources = (await Promise.all(urls.map(extractUrl))).filter((s): s is { url: string; text: string } => !!s);
    const out = await aiMarketingPost({ sources, content, take });
    res.json({ ok: true, ...out, sourcesRead: sources.length, sourcesGiven: urls.length });
  } catch (e: any) { res.status(400).json({ ok: false, error: e.message || 'Generation failed' }); }
});

// Free stock-photo search (Pexels) — hero-image picker for the studio.
router.get('/marketing/socials/image-search', requireAdmin, async (req: Request, res: Response) => {
  try { res.json({ ok: true, images: await searchFreeImages(String(req.query.q || '')) }); }
  catch (e: any) { res.status(400).json({ ok: false, error: e.message || 'Image search failed' }); }
});

// Preview — the EXACT page the website publish would produce, rendered without writing anything.
router.post('/marketing/socials/preview-website', requireAdmin, async (req: Request, res: Response) => {
  res.setHeader('Content-Security-Policy', "default-src 'self' 'unsafe-inline' data: https:; img-src * data: https:; style-src 'unsafe-inline'");
  res.send(renderArticlePreview({
    title: String(req.body.title || ''), slug: String(req.body.slug || 'preview'),
    excerpt: String(req.body.excerpt || ''), articleHtml: String(req.body.articleHtml || ''),
    imageUrl: String(req.body.imageUrl || '').trim() || undefined,
  }));
});

router.post('/marketing/socials/publish-website', requireAdmin, async (req: Request, res: Response) => {
  try {
    const r = await publishNewsArticle({
      title: String(req.body.title || ''), slug: String(req.body.slug || ''),
      excerpt: String(req.body.excerpt || ''), articleHtml: String(req.body.articleHtml || ''),
      imageUrl: String(req.body.imageUrl || '').trim() || undefined,
    });
    res.json({ ok: true, url: r.url });
  } catch (e: any) { res.status(400).json({ ok: false, error: e.message || 'Publish failed' }); }
});

router.post('/marketing/socials/push-buffer', requireAdmin, async (req: Request, res: Response) => {
  try {
    if (!(await bufferConfigured())) { res.status(400).json({ ok: false, error: 'Buffer API key not set — add it in Settings → Integrations.' }); return; }
    const mode = req.body.mode === 'schedule' ? 'schedule' : 'now';
    const dueAt = mode === 'schedule' ? String(req.body.dueAt || '') : undefined;
    if (mode === 'schedule' && !dueAt) { res.status(400).json({ ok: false, error: 'Pick a date and time, or choose Post now.' }); return; }
    const link = String(req.body.link || '').trim();
    const channels = await getChannels();
    const results: Record<string, string> = {};
    for (const network of ['linkedin', 'facebook'] as const) {
      const text = String(req.body[network] || '').trim();
      if (!text) continue;
      const ch = channelFor(channels, network);
      if (!ch) { results[network] = `no ${network} channel connected in Buffer`; continue; }
      const body = link ? `${text}\n\n${link}` : text;
      const imageUrl = String(req.body.imageUrl || '').trim() || undefined;
      const r = await createBufferPost(ch.id, body, mode, network, dueAt, imageUrl);
      results[network] = r.error ? `FAILED: ${r.error}` : (mode === 'now' ? 'posted' : `scheduled for ${dueAt}`);
      await new Promise((r2) => setTimeout(r2, 800)); // Buffer rate-limit spacing
    }
    if (!Object.keys(results).length) { res.status(400).json({ ok: false, error: 'Nothing to post — both social boxes are empty.' }); return; }
    res.json({ ok: true, results });
  } catch (e: any) { res.status(400).json({ ok: false, error: e.message || 'Buffer push failed' }); }
});

// ══ Marketing → Mass Mailer ══════════════════════════════════════════════════
// Bulk email to contacts on their customer's DEFAULT domain only (lib/mass-mailer).

// Campaign list.
router.get('/marketing/mass-mailer', requireAdmin, async (req: Request, res: Response) => {
  let campaigns: any[] = [];
  try {
    const { rows } = await pool.query(
      `SELECT c.*,
              (SELECT COUNT(*)::int FROM mail_campaign_recipients r WHERE r.campaign_id=c.id) AS total,
              (SELECT COUNT(*)::int FROM mail_campaign_recipients r WHERE r.campaign_id=c.id AND r.status='sent') AS sent,
              (SELECT COUNT(*)::int FROM mail_campaign_recipients r WHERE r.campaign_id=c.id AND r.status='failed') AS failed
       FROM mail_campaigns c ORDER BY c.created_at DESC`);
    campaigns = rows;
  } catch { /* tables appear on first deploy's prisma db push */ }
  res.render('marketing/mass-mailer', { user: req.session.user!, campaigns, notice: req.query.msg || null });
});

// Compose (new) / edit draft — same form.
router.get('/marketing/mass-mailer/new', requireAdmin, async (req: Request, res: Response) => {
  res.render('marketing/mass-mailer-form', { user: req.session.user!, campaign: null, aiReady: await aiComposeConfigured() });
});

router.get('/marketing/mass-mailer/:id/edit', requireAdmin, async (req: Request, res: Response) => {
  const id = parseInt(String(req.params.id), 10);
  const { rows } = await pool.query('SELECT * FROM mail_campaigns WHERE id=$1', [id]);
  if (!rows.length) { res.status(404).render('error', { message: 'Campaign not found.' }); return; }
  if (rows[0].status !== 'draft') { res.redirect('/marketing/mass-mailer/' + id); return; }
  res.render('marketing/mass-mailer-form', { user: req.session.user!, campaign: rows[0], aiReady: await aiComposeConfigured() });
});

// Live audience preview for the compose page.
router.get('/marketing/mass-mailer/audience.json', requireAdmin, async (req: Request, res: Response) => {
  try {
    const f = req.query.status === 'all' ? 'all' : 'active';
    res.json({ ok: true, recipients: await audience(f), coverage: await audienceCoverage(f) });
  } catch (e: any) { res.status(400).json({ ok: false, error: e.message }); }
});

// Claude: draft a campaign email from rough notes / improve the current draft.
router.post('/marketing/mass-mailer/ai-draft', requireAdmin, async (req: Request, res: Response) => {
  try {
    const out = await aiMassMailEmail({ notes: String(req.body.notes || ''), tone: String(req.body.tone || '').trim() || null });
    res.json({ ok: true, ...out });
  } catch (e: any) { res.status(400).json({ ok: false, error: e.message || 'Draft failed' }); }
});

router.post('/marketing/mass-mailer/ai-improve', requireAdmin, async (req: Request, res: Response) => {
  try {
    res.json({ ok: true, bodyHtml: await aiImproveEmailHtml(String(req.body.bodyHtml || '')) });
  } catch (e: any) { res.status(400).json({ ok: false, error: e.message || 'Improve failed' }); }
});

const parseCampaignBody = (req: Request) => ({
  name: String(req.body.name || '').trim() || 'Untitled campaign',
  subject: String(req.body.subject || '').trim(),
  bodyHtml: String(req.body.bodyHtml || ''),
  statusFilter: (req.body.statusFilter === 'all' ? 'all' : 'active') as 'active' | 'all',
  excludeEmails: String(req.body.excludeEmails || '').split(',').map((e) => e.trim().toLowerCase()).filter(Boolean),
  createdBy: req.session.user!.id,
});

router.post('/marketing/mass-mailer', requireAdmin, async (req: Request, res: Response) => {
  try {
    const input = parseCampaignBody(req);
    if (!input.subject || !input.bodyHtml.trim()) { res.status(400).json({ ok: false, error: 'Subject and message are both required.' }); return; }
    const id = await createCampaign(input);
    res.json({ ok: true, id });
  } catch (e: any) { res.status(400).json({ ok: false, error: e.message || 'Could not create campaign' }); }
});

router.post('/marketing/mass-mailer/:id/update', requireAdmin, async (req: Request, res: Response) => {
  try {
    const id = parseInt(String(req.params.id), 10);
    const input = parseCampaignBody(req);
    if (!input.subject || !input.bodyHtml.trim()) { res.status(400).json({ ok: false, error: 'Subject and message are both required.' }); return; }
    await updateDraft(id, input);
    res.json({ ok: true, id });
  } catch (e: any) { res.status(400).json({ ok: false, error: e.message || 'Could not update campaign' }); }
});

// Campaign detail + live status.
router.get('/marketing/mass-mailer/:id', requireAdmin, async (req: Request, res: Response) => {
  const id = parseInt(String(req.params.id), 10);
  if (!id) { res.status(404).render('error', { message: 'Campaign not found.' }); return; }
  const { rows } = await pool.query('SELECT * FROM mail_campaigns WHERE id=$1', [id]);
  if (!rows.length) { res.status(404).render('error', { message: 'Campaign not found.' }); return; }
  const rec = await pool.query(
    `SELECT * FROM mail_campaign_recipients WHERE campaign_id=$1 ORDER BY customer_name ASC, full_name ASC`, [id]);
  res.render('marketing/mass-mailer-detail', {
    user: req.session.user!, campaign: rows[0], recipients: rec.rows, notice: req.query.msg || null,
    signatureHtml: await campaignSignatureHtml(),
  });
});

router.get('/marketing/mass-mailer/:id/status.json', requireAdmin, async (req: Request, res: Response) => {
  const id = parseInt(String(req.params.id), 10);
  const c = await pool.query('SELECT status FROM mail_campaigns WHERE id=$1', [id]);
  const r = await pool.query(
    `SELECT status, COUNT(*)::int AS n FROM mail_campaign_recipients WHERE campaign_id=$1 GROUP BY status`, [id]);
  const counts: Record<string, number> = {};
  r.rows.forEach((x: any) => { counts[x.status] = x.n; });
  const rec = await pool.query(
    `SELECT id, status, error, sent_at FROM mail_campaign_recipients WHERE campaign_id=$1`, [id]);
  res.json({ ok: true, status: c.rows[0]?.status, counts, recipients: rec.rows });
});

router.post('/marketing/mass-mailer/:id/test', requireAdmin, async (req: Request, res: Response) => {
  try {
    const u = req.session.user!;
    await sendTest(parseInt(String(req.params.id), 10), u.email, u.displayName);
    res.json({ ok: true, to: u.email });
  } catch (e: any) { res.status(400).json({ ok: false, error: e.message || 'Test send failed' }); }
});

router.post('/marketing/mass-mailer/:id/send', requireAdmin, async (req: Request, res: Response) => {
  try { await startSending(parseInt(String(req.params.id), 10)); res.json({ ok: true }); }
  catch (e: any) { res.status(400).json({ ok: false, error: e.message || 'Could not start sending' }); }
});

router.post('/marketing/mass-mailer/:id/pause', requireAdmin, async (req: Request, res: Response) => {
  await pauseSending(parseInt(String(req.params.id), 10));
  res.json({ ok: true });
});

router.post('/marketing/mass-mailer/:id/retry-failed', requireAdmin, async (req: Request, res: Response) => {
  try { res.json({ ok: true, retried: await retryFailed(parseInt(String(req.params.id), 10)) }); }
  catch (e: any) { res.status(400).json({ ok: false, error: e.message }); }
});

router.post('/marketing/mass-mailer/:id/delete', requireAdmin, async (req: Request, res: Response) => {
  const id = parseInt(String(req.params.id), 10);
  await pool.query("DELETE FROM mail_campaigns WHERE id=$1 AND status IN ('draft','sent','failed','paused')", [id]);
  res.redirect('/marketing/mass-mailer?msg=' + encodeURIComponent('Campaign deleted'));
});

// ── Public unsubscribe (no auth — linked from every campaign email) ────────────
const unsubPage = (title: string, msg: string) =>
  `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">`
  + `<title>${title} — Lumen IT Solutions</title></head>`
  + `<body style="font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#f1f5f9;margin:0;">`
  + `<div style="max-width:480px;margin:12vh auto;background:#fff;border-radius:16px;padding:36px 32px;box-shadow:0 12px 30px rgba(2,6,23,.12);text-align:center;">`
  + `<h1 style="font-size:22px;margin:0 0 10px;color:#0f172a;">${title}</h1>`
  + `<div style="color:#475569;font-size:15px;line-height:1.5;">${msg}</div>`
  + `<p style="color:#94a3b8;font-size:13px;margin:24px 0 0;">Lumen IT Solutions</p>`
  + `</div></body></html>`;

router.get('/unsubscribe/:token', async (req: Request, res: Response) => {
  const token = String(req.params.token || '');
  const contact = await contactForUnsubToken(token).catch(() => null);
  if (!contact) { res.status(404).send(unsubPage('Link not recognised', 'This unsubscribe link is not valid. If you meant to stop our emails, just reply to any of them and we will sort it.')); return; }
  if (contact.opted_out) { res.send(unsubPage('Already unsubscribed', `<p>${contact.email || 'You'} will not receive marketing updates from us.</p>`)); return; }
  // Confirm with a button (a bare GET can be triggered by link scanners / prefetch).
  res.send(unsubPage('Unsubscribe from Lumen updates',
    `<p>Stop marketing updates to <strong>${contact.email || 'this address'}</strong>?</p>`
    + `<form method="post" action="/unsubscribe/${token}" style="margin:18px 0 0;">`
    + `<button type="submit" style="background:#0ea5b7;color:#fff;border:0;font-weight:600;padding:11px 26px;border-radius:6px;font-size:15px;cursor:pointer;">Unsubscribe</button>`
    + `</form>`));
});

router.post('/unsubscribe/:token', async (req: Request, res: Response) => {
  const ok = await optOutByToken(String(req.params.token || '')).catch(() => false);
  res.send(ok
    ? unsubPage('You are unsubscribed', '<p>Done — you will not receive marketing updates from us. Service emails about your account are unaffected.</p>')
    : unsubPage('Link not recognised', 'This unsubscribe link is not valid. If you meant to stop our emails, just reply to any of them and we will sort it.'));
});

export default router;
